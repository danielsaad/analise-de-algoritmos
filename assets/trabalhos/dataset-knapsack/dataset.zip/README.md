# Descrição dos Arquivos

## Pasta Large Scale

Possuí 3 categorias de arquivos:
- KnapPI_1: fraca correlação entre peso e valor de cada item
- KnapPI_2: média correlação entre o peso e valor de cada item
- KnapPI_3: forte correlação entre o peso e o valor de cada item

### Sintaxe

Primeira Linha: número de itens `n`e capacidade da mochila `w`
Próximas `n`linhas: valor e peso de cada item
Última linha: vetor de booleanos indicando quais itens compõe uma solução ótima

### Pasta Large Scale Optimum

Contém o benefício máximo para cada arquivo da pasta Large Scale